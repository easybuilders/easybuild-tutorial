#include <iostream>
#include "ebtutorial-message.hpp"

int main(){
    std::cout << ebtutorial::message << std:: endl;
}

