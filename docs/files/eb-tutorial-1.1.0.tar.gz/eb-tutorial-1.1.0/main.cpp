#include <iostream>
#include "ebtutorial-message.hpp"

int main(){
    std::cout << "I have a message for you:" << std::endl;
    std::cout << ebtutorial::message << std:: endl;
}

