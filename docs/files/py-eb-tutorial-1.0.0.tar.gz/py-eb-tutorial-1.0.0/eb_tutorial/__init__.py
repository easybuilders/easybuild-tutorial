import subprocess
import numpy

def main():
    subprocess.call(['eb-tutorial'])
